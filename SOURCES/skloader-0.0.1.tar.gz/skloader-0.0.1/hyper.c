#include <stdint.h>
#include "inc.h"

#define LINUX_VERSION_CODE 266002
#define PKG_ABI 0

#define HV_CANONICAL_VENDOR_ID  0x80
#define HV_LINUX_VENDOR_ID      0x8100

#define HV_X64_MSR_GUEST_OS_ID  0x40000000
#define HV_X64_MSR_HYPERCALL    0x40000001

union hv_x64_msr_hypercall_contents {
    uint64_t as_uint64;
    struct {
        uint64_t enable:1;
        uint64_t reserved:11;
        uint64_t guest_physical_address:52;
    };
};

static inline void write_msr(uint64_t msr, uint64_t value)
{
    uint32_t low = value & 0xFFFFFFFF;
    uint32_t high = value >> 32;

    asm volatile (
        "wrmsr"
        :
        : "c"(msr), "a"(low), "d"(high)
    );
}

static inline uint64_t read_msr(uint64_t msr)
{
    uint32_t low, high;

    asm volatile (
        "rdmsr"
        : "=a"(low), "=d"(high)
        : "c"(msr)
    );

    return ((uint64_t)high << 32) | low;
}

static inline  uint64_t hv_generate_guest_id(uint64_t d_info1,
    uint64_t kernel_version, uint64_t d_info2)
{
    uint64_t guest_id = 0;

    guest_id = (((uint64_t)HV_LINUX_VENDOR_ID) << 48);
    guest_id |= (d_info1 << 48);
    guest_id |= (kernel_version << 16);
    guest_id |= d_info2;

    return guest_id;
}

void hv_init_hypercalls(void)
{
    uint64_t guest_id;
    union hv_x64_msr_hypercall_contents hypercall_msr;

    guest_id = hv_generate_guest_id(HV_CANONICAL_VENDOR_ID, LINUX_VERSION_CODE,
        PKG_ABI);
    write_msr(HV_X64_MSR_GUEST_OS_ID, guest_id);

    hypercall_msr.as_uint64 = read_msr(HV_X64_MSR_HYPERCALL);
    hypercall_msr.enable = 1;
    write_msr(HV_X64_MSR_HYPERCALL, hypercall_msr.as_uint64);
}
