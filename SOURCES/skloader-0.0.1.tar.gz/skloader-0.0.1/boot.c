#include "stdio.h"
#include "stdint.h"
#include "bootparam.h"
#include "inc.h"

#define	KERNEL_START_OFFSET	0x200000
#define CMDLINE_SIZE		512

struct boot_params bootparams;
char cmdline[CMDLINE_SIZE] = "noxsave possible_cpus=";

static void add_e820_entry(uint64_t start_addr, uint64_t end_addr, uint32_t type)
{
	struct boot_e820_entry *entry = &(bootparams.e820_table[bootparams.e820_entries++]);
	
	entry->addr = start_addr;
        entry->size = end_addr - start_addr;
        entry->type = type;
}

static void populate_possible_cpus(int cpus)
{
	int i = 0, count = 0, __cpus = cpus;

	while (__cpus) {
		__cpus /= 10;
		count++;
	}

	while (cmdline[i] != '\0')
		i++;

	i+=count;
	cmdline[i--] = '\0';

	while(count--) {
		cmdline[i--] = (cpus % 10) + '0';
		cpus = cpus /= 10;
	}
}

struct boot_params* build_boot_params(int possible_cpus, uint64_t start_phys_mem,
				      uint64_t end_phys_mem, uint64_t total_mem)
{
	uint64_t cmdline_ptr = (uint64_t)cmdline;

	serial_write("Building boot params\n");
	populate_possible_cpus(possible_cpus);
	bootparams.hdr.type_of_loader = 0xFF;
	bootparams.hdr.hardware_subarch = X86_SUBARCH_LGUEST;
	bootparams.hdr.cmd_line_ptr = cmdline_ptr & 0xFFFFFFFF;
	bootparams.ext_cmd_line_ptr = (cmdline_ptr >> 32) & 0xFFFFFFFF;
	add_e820_entry(0, start_phys_mem, E820_RESERVED);
	add_e820_entry(start_phys_mem, end_phys_mem, E820_RAM);
	add_e820_entry(end_phys_mem, total_mem, E820_RESERVED);

	return &bootparams;
}

void start_kernel(uint64_t possible_cpus, uint64_t start_phys_mem,
		  uint64_t end_phys_mem, uint64_t total_mem)
{
	void (*__start_kernel)(uint64_t, struct boot_params*);
	serial_init();
	serial_write("*******************SECURE KERNEL LOADER*******************\n");
	hv_init_hypercalls();
	build_boot_params((int)possible_cpus, start_phys_mem, end_phys_mem, total_mem);
	serial_write("Starting Kernel............\n\n");
	__start_kernel = (void(*)(uint64_t, struct boot_params*))(start_phys_mem + KERNEL_START_OFFSET);
	__start_kernel(0, &bootparams);
}
