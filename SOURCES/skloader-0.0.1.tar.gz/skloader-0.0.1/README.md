Simple bootloader to load linux in VTL1.
Compiled to be loaded at 0x8000000 (no relocation support)

To build:
	make

Output:
	skloader.bin
