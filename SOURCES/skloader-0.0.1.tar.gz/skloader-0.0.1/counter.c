#include <stdint.h>

int entry_counter = 0x0;

int get_entry_count()
{
	return ++entry_counter;
}
