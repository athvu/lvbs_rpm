#include <stdint.h>
#include "inc.h"

#define COM2	0x2F8

static inline void outb(uint16_t port, uint8_t data)
{
	asm volatile ("outb %0, %1"
			:
			: "a"(data), "d"(port));
}
static inline uint8_t inb(uint16_t port)
{
	uint8_t data;
	asm volatile ("inb %1, %0"
			: "=a"(data)
			: "d"(port));
}

void serial_writeb(char ch)
{
	while ((inb(COM2 + 5) & 0x20) == 0);
	outb(COM2, ch);
}

void serial_write(char *str)
{
	while (*str) {
		if (*str == '\n')
			serial_writeb('\r');
		serial_writeb(*str);
		str++;
	}
}

void serial_init(void)
{
	outb(COM2 + 1, 0x00); // Disable all interrupts
	outb(COM2 + 2, 0xC7); // Enable FIFO, clear them, with 14-byte threshold
	outb(COM2 + 4, 0x0F);
}
