
void hv_init_hypercalls(void);
void serial_init(void);
void serial_write(char *str);
